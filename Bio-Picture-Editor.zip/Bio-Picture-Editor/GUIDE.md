# 图注工坊 · Windows 本地生物医学图片标注

用于普通 8 位 PNG/JPEG 实验照片的手动标注。支持中文文字、箭头、关联引线、直线、矩形和椭圆，可保存可编辑项目并导出合成 PNG。所有图片仅在本机处理；不自动上传，不联网识别，不生成诊断。

## Windows 开始使用

这是 Windows x64 轻量发布包，首次需安装 Node.js 22.12 或更新版本并联网运行 Setup.cmd，之后双击启动.vbs／Start.vbs 即可使用。详见操作指南.md。

1. 将整个项目解压到任意可写目录。中文及含空格的路径可使用；请不要放入需要管理员权限的 Program Files。
2. 安装官方 **Node.js 22.12 或更新版本**（https://nodejs.org/）。
3. 第一次双击 `Setup.cmd`。它安装锁定版本的依赖并构建应用，需要联网一次。
4. 日常双击 **`Start.vbs`**，后台启动本地服务并在默认浏览器打开 **http://127.0.0.1:4317**。可在 Edge 打开同一地址。没有额外命令行窗口。
5. 保存项目后双击 **`Stop.vbs`** 停止服务。仅关闭浏览器不会停止服务。

`config.json` 的 `port` 可改为 4318 等空闲端口。端口冲突时启动器会选择后续空闲端口并更新此文件，浏览器自动打开当前端口。

若学校或系统禁用 Windows Script Host，可右键 `scripts/start.ps1` → 使用 PowerShell 运行；停止用 `scripts/stop.ps1`。PowerShell 脚本保留 UTF-8 BOM，路径均使用 LiteralPath 和独立参数。新版启动与停止脚本支持本机安装的 Node.js，说明见 PACKAGE-REPORT.md；不保证通过学校或单位的脚本执行策略。

开发/云端运行：`npm ci` → `npm run build` → `npm start`。设置环境变量 `BIO_PORT` 可配置端口，`BIO_DATA_DIR` 可配置数据目录。运行时工作目录须为项目根目录。核心使用不需要 Playwright；它仅用于测试。

## 一次完整工作流

打开照片或将照片拖入中央画布，也可点击画布后 Ctrl+V 粘贴剪贴板图片。打开 `examples/example.biozip` 可以开始体验。

左侧选择工具，拖动绘制箭头/直线/区域，点击放置文字。关联引线从指向位置拖到文字位置；移动文字框时，尖端固定。按住 Alt 拖动可移动整组。双击文字/关联标注在右侧文本框编辑中文、多行内容。

右侧调整颜色、字号、粗细、实虚线、描边、底板和填充；可多选并批量设置样式。内置三组预设可以更新保存。底图锁定。文字框右侧控制点调整宽度并重新换行，左下控制点调整字号；不会拉伸文字。箭头和直线有端点控制点，矩形/椭圆有尺寸控制点。控制点按屏幕尺寸显示，放大后仍容易选中。

展开“版面与留白”调整四周空间，原图不会缩小。留白变大后可点击“适应窗口”。底部显示方向校正后的原图像素坐标。标注可临时隐藏，以查看原图。

按 Ctrl+S 保存项目。导出 PNG 可选择原分辨率、2×、4×。导出也在本地项目 `exports/` 保留副本，可用于浏览器下载受限的环境。便携包用于移动项目或备份；它包含原图、显示图和所有标注。

## 快捷键与鼠标

| 操作 | 按键 |
|---|---|
| 打开图片 / 便携项目 | Ctrl+O |
| 保存项目 | Ctrl+S |
| 撤销 / 重做 | Ctrl+Z / Ctrl+Y 或 Ctrl+Shift+Z |
| 复制 / 粘贴标注 | Ctrl+C / Ctrl+V |
| 复制当前标注 | Ctrl+D |
| 删除选中标注 | Delete |
| 微调 / 较大步长 | 方向键 1 px / Shift+方向键 10 px |
| 取消绘制 / 退出选择 | Esc |
| 选择 / 箭头 / 文字 / 直线 / 矩形 / 椭圆 | V / A / T / L / R / E |
| 鼠标位置为中心缩放 | 画布内滚轮；Ctrl+滚轮也由画布处理 |
| 平移 | 空格+左键拖动，或中键拖动 |
| 多选 | 选择工具 Shift+点击画布对象或列表 |
| 正圆 / 正方形 | 绘制时按 Shift |
| 箭头 / 直线锁定 45° 方向 | 绘制时按 Shift |
| 关联标注整组移动 | Alt+拖动或 Alt+方向键 |

文字输入区域中，字母、空格、方向键、Delete、复制粘贴和撤销由文本输入处理；组合输入期间不会触发绘图快捷键。绘图快捷键主要在画布焦点内生效。Ctrl+S 仍用于保存。

## 保存、恢复和备份

默认数据位置：**项目目录/data/projects/项目 UUID/**。

```text
project.json          语义清晰的 JSON；version=1；包含修订号和稳定对象 ID
original.png / .jpg   原始导入文件，完整保留
display.png          EXIF 方向校正后的 8 位 sRGB 显示资源
history/              每次成功保存前的 JSON 修订；复用不可变图片资源
exports/              界面 PNG 导出副本
preview.png           CLI 请求预览后生成的完整合成图
annotations.md        CLI 请求预览后生成的标注清单
```

JSON 中 `image.original` 与 `image.display` 在目录格式中为空字符串，字节放在相邻资源文件；服务读取时重建完整模型。文件包 `.biozip` 是 ZIP，包含 `project.json`、`original.png/.jpg`、`display.png`，不包含原绝对路径或临时 URL。请通过界面打开包；移到新的机器后可以继续保存。

每次保存使用临时文件+原子重命名；成功后修订号递增。旧 JSON 保存在 `history`。JSON 损坏、未知版本、重复 ID、错误图片关系或资源校验不通过会明确报错。历史不是无限制自动清理，长期使用可备份后清理旧修订。

工作区草稿以约 500 ms 防抖写入 IndexedDB，包含所有打开的图片资源、标注、视口和未保存状态；刷新或重开页面恢复多个标签页，兼容旧版本单图草稿。撤销历史仅在当前会话内保留。空间不足会提示显式保存，不能仅依赖缓存。备份方式：导出 `.biozip`，或停止服务后复制完整 `data/projects` 目录。浏览器草稿与主机/端口绑定，切换 localhost/127.0.0.1 或端口不会共享草稿。

## 坐标与图像质量

所有 `geometry` 使用 **EXIF 方向校正后的原图像素坐标**：原图左上角 (0,0)，x 向右、y 向下，单位为 `image-pixel`。图旁文字可以使用负坐标，或大于原图宽高的坐标。文档/版面原点为留白左上角，原图坐标加上 left/top 留白得到版面坐标；视口使用独立的平移和缩放。缩放、窗口尺寸、DPR 和 Windows 显示缩放不会写入标注几何信息。

文字、线宽和箭头头部均以文档像素保存。导出以完整文档像素重新渲染，控制点、选择框和界面不参与。UI 与 CLI 调用同一校验、Canvas 2D 渲染与 PNG 导出逻辑；编辑预览复用相同标注绘制和文本换行函数。导出前服务重新解码图片，并加载内置中文字体。未安装的系统字体会明确报错，请改用内置思源黑体。

原图 4000×3000，无留白时默认仍输出 4000×3000；左右各加 200、上下各加 100 后为 4400×3200。示例原图 1200×800，加右侧 350 后成图 **1550×800**。2×/4×会同比例放大文字与几何尺寸，不增加照片真实细节。

支持上限：输入文件/项目包 100 MB；图像和导出总像素最多 6400 万；输出单边最多 16384 px；最多 2000 个标注。6000×4000 的 2×会达到 9600 万像素，因此明确拒绝，不能静默降级。尺寸限额属于保护性限制，并不保证每台电脑都能在上限附近稳定运行；图片资源、画布、解码和导出会同时占用内存。

支持常见 8 位 PNG/JPEG。16 位、高位深、CMYK、多页及其他格式会拒绝。含 ICC 配置会询问是否接受转换为 8 位 sRGB，原文件完整保留；PNG 的无损编码只针对最终合成像素，不恢复 JPEG 细节，也不保证所有色彩配置/元数据原样保留。不修改亮度、颜色、对比度、锐度或组织内容。

## Codex 协作

浏览器页面与程序化协作分别提供。Codex 读取 `original`、`display.png`、`project.json`、`preview.png`、`annotations.md`；原图 SHA256、EXIF 方向、导入前后宽高都在项目内。针对原文件视觉坐标应先应用记录的 EXIF 方向，建议用 `display.png` 定位像素。

先保存项目并启动服务，在项目根目录运行：

```powershell
npm run cli -- list
npm run cli -- summary PROJECT_ID
npm run cli -- patch PROJECT_ID ANNOTATION_ID REVISION examples/patch.json
npm run cli -- preview PROJECT_ID preview.png
npm run cli -- export PROJECT_ID final.png 1
npm run cli -- crop PROJECT_ID local.png 900 100 200 200
```

`summary` 返回当前修订号、对象 ID、几何、标签及项目目录。`patch` 读取 JSON 文件，支持 label、description、geometry、style、visible、locked、status；未知字段/错误尺寸被拒绝。`examples/patch.json` 演示中文标签、颜色与 `status: suggested`；不要使用固定旧修订号。位置示例：

```json
{"label":"位置说明","geometry":{"x":1230,"y":180},"style":{"fontSize":28,"color":"#2563eb"},"status":"suggested"}
```

修改关联标注的 x/y 只移动文字框，x2/y2 为箭头尖端。全部对象 ID 在编辑、移动和排序后保持稳定。`status` 的 `user`、`suggested`、`confirmed` 区分用户内容、待确认模型建议和人工已确认内容；软件不验证医学正确性。

CLI 通过本机服务提交，不直接绕过文件锁。修订号过期返回 409，不写入。界面约每 1.5 秒查询修订；无未保存修改时同步，并可撤销外部修改。有未保存编辑时显示冲突条，不覆盖当前编辑；可先备份便携包，再载入外部版本，或保留当前编辑、基于新修订显式保存。旧版本同时保存在 `history`。

`crop` 生成方向校正后的原图局部（不含标注），并写旁文件 `local.png.json`，记录项目及原图范围。此功能为协作资料裁剪，不是编辑器的非破坏性裁剪工具。完整预览包含可见标注和留白，尺寸与原分辨率导出一致。

**Codex 内置浏览器**：如果你的本地 Codex 提供打开浏览器的工具，请让它打开 `http://127.0.0.1:4317`。早期云端浏览器访问云端地址曾报 `ERR_BLOCKED_BY_CLIENT`；当前本机内置浏览器已验证可访问本地应用，并完成多图片编辑、保存和导出操作，详见 REPAIR-REPORT.md。仍可通过上述文件和 CLI 协作，或用普通 Edge 访问。如果内置浏览器与本地服务不在同一机器，localhost 不代表同一个环境，不能直接互访；本项目不自动开启公网或隧道。

## 本地服务保护与技术选择

- React + TypeScript + Vite：中文面板、类型化模型、离线静态构建。
- Konva / react-konva：成熟的画布交互与独立命中区域；采用按对象类型的控制点，避免文字拉伸。
- Node + Express：只监听 **127.0.0.1**；校验 Host/Origin；每个 API 请求要求本地随机会话令牌，禁止跨来源请求，无 CORS 放行。
- Sharp：读取实际格式、位深与 EXIF，方向校正，保留原文件。
- @napi-rs/canvas + 随附 Noto 中文字体：服务端和 CLI 的统一全尺寸 PNG 导出；不需要浏览器截图，不需要日常运行 Chromium。
- Zod：共享格式校验；fflate：便携项目包。

服务仅使用数据目录下 UUID 项目路径，拒绝路径越界和符号链接；同一个数据目录只允许一个服务实例，防止不同端口跨进程覆盖修订；项目包不解压任意文件路径。`data/runtime.json` 含本机会话令牌，仅供本机 CLI 使用，不应分享。它不是面向多用户或公网部署的认证系统。

## 开发验证与本次边界

`npm test`：核心逻辑测试。`npm run verify`：需要另行执行 `npx playwright install chromium` 并保持 4317 服务启动，验证浏览器工作流；测试使用新的浏览器上下文，会在数据目录创建人工测试项目。`tests/additional.ts` 验证 CLI 与对象列表；运行需要先成功完成主验证并存在示例项目。

结果与截图见 `tests/results.json`、`tests/additional-results.json`、`tests/editor-example.png`、`tests/narrow.png`。详细记录见 `TEST-REPORT.md`。

P0 已实现并在云端 Linux Chromium 141 验证核心工作流；Windows Edge、本机真实中文 IME、系统显示缩放未全面实测；Windows 轻量包说明见 PACKAGE-REPORT.md。中文组合输入仅测试浏览器组合事件保护；不能等同真实 Windows IME 验证。

P1 尚未实现：自动编号、多边形 ROI/节点、折线引线、比例尺与测量、对齐/均匀分布、非破坏性裁剪/旋转/翻转。数据模型预留每图 calibration（或 null），未标定不生成真实单位比例尺，也不会由 20×/40×推算 μm/pixel。P2：TIFF/DICOM/全切片、多通道、面积测量、多图拼版、桌面安装包、自动识别等不在此版本内；界面没有无效占位按钮。
